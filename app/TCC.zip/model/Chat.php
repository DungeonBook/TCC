<?php

class Chat
{

    private ?int $id;
    private ?salaJogadores $salaJogadores;
    private ?int $dataHora;
    private ?string $mensagem;

    //TODO - Getters e Setters

}